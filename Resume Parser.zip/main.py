# Author: Vishal Mate
import streamlit as st
import pandas as pd
import os
import csv
import utils
import spacy
import pprint
from spacy.matcher import Matcher
import multiprocessing as mp
import streamlit as st
from fpdf import FPDF

csv_file_path = 'skills.csv'
with open(csv_file_path, 'r') as file:
    reader = csv.reader(file)
    data_list = [item for row in reader for item in row]
    
# Define a function to create the PDF
class PDF(FPDF):
    def header(self):
        self.set_font('Arial', 'B', 12)
        self.cell(0, 10, 'Resume', 0, 1, 'C')

    def chapter_title(self, title):
        self.set_font('Arial', 'B', 12)
        self.cell(0, 10, title, 0, 1, 'L')
        self.ln(5)

    def chapter_body(self, body):
        self.set_font('Arial', '', 12)
        self.multi_cell(0, 10, body)
        self.ln()


class ResumeParser(object):
    def __init__(self, resume):
        nlp = spacy.load('en_core_web_sm')
        self.__matcher = Matcher(nlp.vocab)
        self.__details = {
            'name'              : None,
            'email'             : None,
            'mobile_number'     : None,
            'skills'            : None
            # 'education'         : None,
            # 'experience'        : None,
            # 'competencies'      : None,
            # 'measurable_results': None
        }
        self.__resume      = resume
        self.__text_raw    = utils.extract_text(self.__resume, os.path.splitext(self.__resume)[1])
        self.__text        = ' '.join(self.__text_raw.split())
        self.__nlp         = nlp(self.__text)
        self.__noun_chunks = list(self.__nlp.noun_chunks)
        self.__get_basic_details()

    def get_extracted_data(self):
        return self.__details

    def __get_basic_details(self):
        name       = utils.extract_name(self.__nlp, matcher=self.__matcher)
        email      = utils.extract_email(self.__text)
        mobile     = utils.extract_mobile_number(self.__text)
        skills     = utils.extract_skills(self.__nlp, self.__noun_chunks)
        #edu        = utils.extract_education([sent.string.strip() for sent in self.__nlp.sents])
        #experience = utils.extract_experience(self.__text)
        entities   = utils.extract_entity_sections(self.__text_raw)
        self.__details['name'] = name
        self.__details['email'] = email
        self.__details['mobile_number'] = mobile
        self.__details['skills'] = skills
        # self.__details['education'] = entities['education']
        #self.__details['education'] = edu
        #self.__details['experience'] = experience
        # try:
        #     self.__details['competencies'] = utils.extract_competencies(self.__text_raw, entities['experience'])
        #     self.__details['measurable_results'] = utils.extract_measurable_results(self.__text_raw, entities['experience'])
        # except KeyError:
        #     self.__details['competencies'] = []
        #     self.__details['measurable_results'] = []
        return

def resume_result_wrapper(resume):
        parser = ResumeParser(resume)
        return parser.get_extracted_data()
    
# Function to handle file upload and storage
def upload_and_store_files(uploaded_files):
    resume_folder = "resumes"
    os.makedirs(resume_folder, exist_ok=True)

    for file in uploaded_files:
        file_extension = file.name.split(".")[-1].lower()
        if file_extension in ["docx", "pdf"]:
            file_path = os.path.join(resume_folder, file.name)
            with open(file_path, "wb") as f:
                f.write(file.getbuffer())
    st.success("Files are successfully uploaded and stored.")

def delete_files_in_resumes_directory():
    for root, directories, filenames in os.walk('resumes'):
        for filename in filenames:
            file_path = os.path.join(root, filename)
            try:
                os.remove(file_path)
                print(f"File '{filename}' deleted successfully.")
            except Exception as e:
                print(f"Error deleting file '{filename}': {e}")
            

if __name__ == '__main__':
    pool = mp.Pool(mp.cpu_count())

    resumes = []
    data = []
    menu = ["Resume Parsing","Resume Generation"]
    choice = st.sidebar.selectbox("Menu",menu)
    if choice == "Resume Parsing":
        st.title("Resume Parsing using NER")
        st.subheader("Upload Resume for Parsing.")
        uploaded_files = st.file_uploader("Choose .docx or .pdf files", type=["docx", "pdf"], accept_multiple_files=True)
        # for file in uploaded_files:
        #         st.markdown(f"{file.name} ({file.type})")
        if uploaded_files:
            upload_and_store_files(uploaded_files)
                
            for root, directories, filenames in os.walk('resumes'):
                for filename in filenames:
                    file = os.path.join(root, filename)
                    resumes.append(file)
            results = [pool.apply_async(resume_result_wrapper, args=(x,)) for x in resumes]
            results = [p.get() for p in results]
            df = pd.DataFrame(results)
            df['skills'] = df['skills'].apply(lambda x: ', '.join(x).split(','))
            df['skills'].drop_duplicates()
            st.write(df)
            delete_files_in_resumes_directory()
            selected_skill = st.text_input('Enter Skill to Filter:')
            if selected_skill:
                filtered_df = df[df['skills'].apply(lambda x: any(selected_skill.lower() in skill.lower() for skill in x))]
                if filtered_df.empty:
                    st.warning("No Resume found with matching Skills.")
                else:
                    st.write(filtered_df)
    elif choice == "Resume Generation":
        st.title("Resume Parsing using NER")
        # Streamlit form
        with st.form("resume_form"):
            st.write("## Create Your Resume")
            fullname = st.text_input("Full Name")
            email = st.text_input("Email Address")
            contact = st.text_input("Contact Number")
            career_obj = st.text_area("Career Objective")
            education = st.text_area("Educational Qualification")
            skills = st.text_area("Skills (separate with commas)")
            experience = st.text_area("Experience")

            submit_button = st.form_submit_button("Generate Resume")

        if submit_button:
            pdf = PDF()
            pdf.add_page()

            pdf.set_font('Arial', 'B', 16)
            pdf.cell(0, 10, fullname, 0, 1, 'C')
            pdf.set_font('Arial', '', 12)
            pdf.cell(0, 10, email, 0, 1, 'C')
            pdf.cell(0, 10, contact, 0, 1, 'C')
            pdf.ln(10)

            pdf.chapter_title('Career Objective')
            pdf.chapter_body(career_obj)

            pdf.chapter_title('Educational Qualification')
            pdf.chapter_body(education)

            pdf.chapter_title('Skills')
            pdf.chapter_body(skills)

            pdf.chapter_title('Experience')
            pdf.chapter_body(experience)

            # Save the PDF to a file
            pdf.output('Resume.pdf')

            # Display a link to download the PDF
            with open('Resume.pdf', 'rb') as file:
                st.download_button(label="Download Resume",
                                   data=file,
                                   file_name="Resume.pdf",
                                   mime="application/pdf")